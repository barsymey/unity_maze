using UnityEngine;

public class Joystick : MonoBehaviour
{
    public GameObject joystickHandle;
    private Vector2 joystickPosition;
    private Vector2 touchPosition;

    public Vector2 JoystickYield()
    {
        Vector3 mousePos = Input.mousePosition;// For android builds Input.GetTouch(0).position
        if (Input.GetMouseButton(0))// Input.touchCount > 0
        {
            print(mousePos);
            joystickPosition = gameObject.transform.position - mousePos;
            if (joystickPosition.magnitude < gameObject.GetComponent<RectTransform>().rect.width / 2)
            {
                joystickHandle.transform.position = Input.mousePosition;
                return -joystickPosition.normalized;
            }
        }
        else
        {
            joystickHandle.transform.position = gameObject.transform.position;
 
        }
        return Vector2.zero;
    }
}
