using UnityEngine;


public class Menu : MonoBehaviour
{
    public LevelGen levelGen;
    public GameObject initialMenu;
    public GameObject pauseMenu;
    public GameObject gameOverMenu;
    public GameObject settingsMenu;
    public GameObject joystickUI;

    public bool joysticActivated = false;
    public void HideMenus()
    {
        initialMenu.SetActive(false);
        pauseMenu.SetActive(false);
        gameOverMenu.SetActive(false);
        settingsMenu.SetActive(false);
    }
    public void StartGame()
    {
        levelGen.ResetLevel();
        HideMenus();
    }
    
    public void GameOver()
    {
        HideMenus();
        gameOverMenu.SetActive(true);
        print("Game Over");
    }

    public void Pause()
    {
        HideMenus();
        pauseMenu.SetActive(true);
        Time.timeScale = 0;
    }

    public void Unpause()
    {
        HideMenus();
        Time.timeScale = 1;
    }

    public void OpenSettingsMenu()
    {
        HideMenus();
        settingsMenu.SetActive(true);
    }

    public void ToggleJoystick()
    {
        if (joystickUI.activeSelf)
        {
            joystickUI.SetActive(false);
            joysticActivated = false;
        }
        else
        {
            joystickUI.SetActive(true);
            joysticActivated = true;
        }
    }
    
    
    private void Start()
    {
        HideMenus();
        initialMenu.SetActive(true);
        joystickUI.SetActive(false);
    }

    private void OnApplicationFocus(bool hasFocus)
    {
        if(!hasFocus){Pause();}
    }
}
