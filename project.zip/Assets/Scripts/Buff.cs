using UnityEngine;

// Script for adjustable buff objects
public class Buff : MonoBehaviour
{
    public float buffDuration;
    public float buffSpeed;
    public int buffHealth;
    public int buffStr;
    public bool buffHunter;

    public void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            other.gameObject.GetComponent<Entity>()
                .BuffEntity(buffDuration, buffHealth, buffStr, buffSpeed, buffHunter);
            Destroy(this.gameObject);
            Destroy(this);
        }
    }
}
