using UnityEngine;

public class PlayerControls : MonoBehaviour
{
    private Vector3 dir;
    private Entity entity;
    public Joystick joystick;
    public Menu menu; 
    
    void Move()
    {
        if (menu.joysticActivated)
        {
            dir =  new Vector3(joystick.JoystickYield().x,0f,joystick.JoystickYield().y);
        }
        else
        {
            dir = new Vector3(Input.GetAxis("Horizontal"), 0f, Input.GetAxis("Vertical")).normalized;
        }        
        transform.Translate(dir*Time.deltaTime*entity.speed);
    }
    
    void Start()
    {
        entity = GetComponent<Entity>();
    }

    private void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.CompareTag("Enemy"))
        {
            if (entity.hunter)
            {
                other.gameObject.GetComponent<Entity>().ModHealth(-entity.str);
            }
            else
            {
                entity.ModHealth(-other.gameObject.GetComponent<Entity>().str);
                other.gameObject.GetComponent<Enemy>().StartRetreat();
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        other.GetComponent<Enemy>().StopRetreat();
    }

    void Update()
    {
        Move();
    }
}
