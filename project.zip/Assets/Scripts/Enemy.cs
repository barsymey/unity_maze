using UnityEngine;
using UnityEngine.AI;

public class Enemy : MonoBehaviour
{
    private NavMeshAgent nav;
    private Entity entity;
    private bool retreat;

    void Start()
    {
        nav = GetComponent<NavMeshAgent>();
        entity = GetComponent<Entity>();
        nav.speed = entity.speed;
    }

    void RunFrom(Collider coll)
    {
        nav.destination = transform.position + ( transform.position - coll.transform.position)/5;
    }

    void RunTo(Collider coll)
    {
        nav.destination = coll.transform.position;
    }

    public void StartRetreat()
    {
        retreat = true;
    }

    public void StopRetreat()
    {
        retreat = false;
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (other.GetComponent<Entity>().hunter || retreat)
            {
                RunFrom(other);
            }
            else
            {
                RunTo(other);
            }
        }
    }
}
