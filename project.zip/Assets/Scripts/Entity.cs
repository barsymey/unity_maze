using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class Entity : MonoBehaviour
{
    public Menu menu;
    public int defHealth = 100;
    public int defStr = 10;
    public float defSpeed = 10;
    private int maxHealth;
    private int health;
    public int str;
    public float speed;
    public bool hunter = false;
    private bool buffed;
    private float buffTime;
    public GameObject hitEffect;
    public GameObject buffEffect;


    
    public void ModHealth(int amount)
    {
        health += amount;
        if (health > maxHealth)
        {
            health = maxHealth;
        }

        if (health <= 0)
        {
            if (gameObject.CompareTag("Player"))
            {
                menu.GameOver();
            }
            else
            {
                Destroy(gameObject);
            }
            health = 0;
        }

        Instantiate(hitEffect, transform.position, Quaternion.identity);
    }

    public void ResetEntity()
    {
        maxHealth = defHealth;
        str = defStr;
        speed = defSpeed;
        hunter = false;
        buffed = false;
        buffEffect.SetActive(false);
    }
    public void BuffEntity(float duration, int healthAmount, int strAmount, float speedAmount, bool hunterState)
    {
        ResetEntity();
        buffed = true;
        buffTime = Time.timeSinceLevelLoad + duration;
        ModHealth(healthAmount);
        str = str + strAmount;
        speed = speed + speedAmount;
        hunter = hunterState;
        buffEffect.SetActive(true);
    }

    private void Start()
    {
        ResetEntity();
        health = maxHealth;
    }

    private void FixedUpdate()
    {
        if(buffed & buffTime < Time.timeSinceLevelLoad){ResetEntity();}
    }
}
