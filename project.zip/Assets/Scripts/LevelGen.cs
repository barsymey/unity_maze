using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class LevelGen : MonoBehaviour
{
    public  GameObject wall_NS;
    public  GameObject wall_EW;
    public  GameObject gate_NS;
    public  GameObject gate_EW;

    public  GameObject[] buffTypes;
    public  int buffAmount = 5;
    public  GameObject[] enemyTypes;
    public  int enemyAmount = 5;

    private  GameObject player;

    private  GameObject[] staticObjects;
    private  GameObject[] enemyObjects;
    private  GameObject[] buffObjects;
    
      void ClearLevel()
    {
            staticObjects = GameObject.FindGameObjectsWithTag("Static");
            foreach (var obj in staticObjects)
            {
                Destroy(obj.gameObject);
            }
            enemyObjects = GameObject.FindGameObjectsWithTag("Enemy");
            foreach (var obj in enemyObjects)
            {
                Destroy(obj.gameObject);
            }
            buffObjects = GameObject.FindGameObjectsWithTag("Buff");
            foreach (var obj in buffObjects)
            {
                Destroy(obj.gameObject);
            }
        
    }

      public void ResetLevel()
      {
          player.transform.position = new Vector3(10f, 1f, 10f);
          player.GetComponent<Entity>().ModHealth(100);
          player.GetComponent<Entity>().ResetEntity();
          try
          {
              ClearLevel();
          }
          catch (Exception e)
          {
          }
          print("bb");
          // Create NS walls
          for (int i = 0; i < 5; i++)
          {
              for (int j = 0; j < 6; j++)
              {
                  if (j == 0 || j == 5)
                  {
                      Instantiate(wall_NS, new Vector3(10f + i * 20f, 0f, j * 20f), Quaternion.identity);
                  }
                  else
                  {
                      if (Random.Range(0, 5) != 0)
                      {
                          Instantiate(gate_NS, new Vector3(10f + i * 20f, 0f, j * 20f), Quaternion.identity);
                      }
                      else
                      {
                          Instantiate(wall_NS, new Vector3(10f + i * 20f, 0f, j * 20f), Quaternion.identity);
                      }
                  }
              }
          }

          // Create EW walls
          for (int i = 0; i < 6; i++)
          {
              for (int j = 0; j < 5; j++)
              {
                  if (i == 0 || i == 5)
                  {
                      Instantiate(wall_EW, new Vector3(i * 20f, 0f, 10f + j * 20f), Quaternion.identity);
                  }
                  else
                  {
                      if (Random.Range(0, 5) != 0)
                      {
                          Instantiate(gate_EW, new Vector3(i * 20f, 0f, 10f + j * 20f), Quaternion.identity);
                      }
                      else
                      {
                          Instantiate(wall_EW, new Vector3(i * 20f, 0f, 10f + j * 20f), Quaternion.identity);
                      }
                  }
              }
          }
          //Spawn enemies
          for (int i = 0; i < enemyAmount; i++)
          {
              Instantiate(enemyTypes[Random.Range(0, enemyTypes.Length)],
                  new Vector3(10f + Random.Range(0, 4) * 20f, 0f, 10f + Random.Range(0, 4) * 20f), Quaternion.identity);
          }
          //Spawn buffs
          for (int i = 0; i < buffAmount; i++)
          {
              Instantiate(buffTypes[Random.Range(0, buffTypes.Length)],
                  new Vector3(10f + Random.Range(0, 4) * 20f, 0f, 10f + Random.Range(0, 4) * 20f), Quaternion.identity);
          }
      }

      public void Start()
      {
          player = GameObject.FindGameObjectWithTag("Player");
      }
}
